package com.hsbc.bts.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import com.hsbc.bts.dao.ProjectDAO;
import com.hsbc.bts.models.Bug;
import com.hsbc.bts.models.Project;
import com.hsbc.bts.models.User;

public class ProjectDAOImpl implements ProjectDAO {
	private static final String url = "jdbc:derby:C:\\ProjectBugDB;create=true";
	private Connection conn = null;
	
	public ProjectDAOImpl() {
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			System.out.println("YES!");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void createConnection() {
		try {
			conn = DriverManager.getConnection(url);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void createProject() {
		// TODO Auto-generated method stub

	}

	@Override
	public void addProject(String name, String date, int userId, String description) {
		// TODO Auto-generated method stub
		createConnection();
		Date d=Date.valueOf(date);
		String sql="insert into Project(prj_name,description,start_date,status)values (?,?,?,?)" ;
		String sql1="select prj_id from Project where prj_name=?";
		String sql2="insert into Proj_users values(prj_id,user_id) values (?,?)";
		int prj_id=0 ;
		try {
			PreparedStatement stmt= conn.prepareStatement(sql);
			stmt.setString(1, name);
			stmt.setString(2, description);
			stmt.setDate(3, d);
			stmt.setString(4, "not completed");
			int cnt=stmt.executeUpdate();
			
			PreparedStatement stmt1 =conn.prepareStatement(sql1);
			stmt.setString(1, name);
			ResultSet rs=stmt1.executeQuery();
			while(rs.next())
			{
				prj_id=rs.getInt("prj_id");
			}
			 
			PreparedStatement stmt2=conn.prepareStatement(sql2);
			stmt.setInt(1, prj_id);
			stmt.setInt(2, userId);
			int cnt2=stmt2.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
				

	}

	@Override
	public void assignProject(int userId, int projectId) {
		createConnection();
		String sql="insert into Proj_users (prj_id,user_id) values(?,?)";
		try {
			PreparedStatement stmt= conn.prepareStatement(sql);
			stmt.setInt(1, projectId);
			stmt.setInt(2, userId);
			int cnt = stmt.executeUpdate(sql);
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
	}

	@Override
	public List<Project> getAllProjects(int userId) {
		// TODO Auto-generated method stub
		createConnection();
		List<Project> allProjects=new ArrayList<Project>();
		
		
		String sql ="select * from Project where prj_id in (select prj_id from Proj_users where user_id=?)";
		try {
			PreparedStatement stmt= conn.prepareStatement(sql);
			stmt.setInt(1, userId);
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				Project project= new Project();
				project.setProjectId(rs.getInt(1));
				project.setName(rs.getString(2));
				project.setDescription(rs.getString(3));
				project.setDate(rs.getString(4));
				project.setStatus(rs.getString(5));
				allProjects.add(project);
			}
			return allProjects;
				
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

			return null;
		}
		
	}

	@Override
	public void updateStatus(int projectId, String status) {
String sql="update table Project set status =? where  prj_id=? ";
 try {
	PreparedStatement stmt= conn.prepareStatement(sql);
	stmt.setString(1, status);
	stmt.setInt(2, projectId);
	
	int a =stmt.executeUpdate();
	
	
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
 
		 
	}

	@Override
	public void createBug() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addBug(String title, String description, int prj_id , int userId, String openDate,
			String severityLevel) {
		// TODO Auto-generated method stub
			
		Date d= Date.valueOf(openDate);
		String sql="insert into Bug(title,description,prj_id,open_date,status,severity) values (?,?,?,?,?,?)";
		String sql2="insert into Bug_user values(?,?)";
		String sql3="select bug_id from bug where title=?";
		int bug_id=0;
		try {
			PreparedStatement stmt=conn.prepareStatement(sql);
			stmt.setString(1, title);
			stmt.setString(2, description);
			stmt.setInt(3, prj_id);
			stmt.setDate(4, d);
			stmt.setString(5, "not completed");
			stmt.setString(6, severityLevel);
			int  a =stmt.executeUpdate();
			
			PreparedStatement stmt3=conn.prepareStatement(sql3);
			stmt3.setString(1, title);
			ResultSet rs= stmt3.executeQuery();
			while (rs.next())
			{
				bug_id=rs.getInt(1);
			}
			
			PreparedStatement stmt2= conn.prepareStatement(sql2);
			stmt2.setInt(2,	userId);
			stmt2.setInt(1, bug_id);
			int a1 =stmt3.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Bug> getAllBugs(int projectId) {
		// TODO Auto-generated method stub
		List<Bug> allBugs= new ArrayList<Bug>();
		String sql="select * from bug where prj_id=?";
		try {
			PreparedStatement stmt= conn.prepareStatement(sql);
			stmt.setInt(1, projectId);
			ResultSet rs= stmt.executeQuery();
			while(rs.next())
			{
				Bug bug =new Bug();
				bug.setBugId(rs.getInt(1));
				bug.setTitle(rs.getString(2));
				bug.setDescription(rs.getString(3));
				bug.setOpenDate(rs.getString(5));
				bug.setMarkForClosing(rs.getBoolean(6));
				bug.setClosedOn(rs.getString(7));
				bug.setStatus(rs.getString(8));
				bug.setSeverityLevel(rs.getString(9));
				
				allBugs.add(bug);

				
			}
			
			return allBugs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
	}

	@Override
	public void assignBug(int userId, int bugId) {
		// TODO Auto-generated method stub
		String sql="insert into Bug_user (bug_id,user_id) values(?,?) ";
		try {
			PreparedStatement stmt= conn.prepareStatement(sql);
			stmt.setInt(1, bugId);
			stmt.setInt(2, userId);
			int a= stmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		
		
		
	}

	@Override
	public void markByDev(int userId, int bugId) {
		String sql="update table Bug set marked_for_closing=? where bug_id=?";
		try {
			PreparedStatement stmt =conn.prepareStatement(sql);
			stmt.setInt(2, bugId);
			stmt.setString(1, "True");
			int a =stmt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void confirmClose(int userId, int bugId) {
		// TODO Auto-generated method stub
		
		String sql="update table Bug set status='completed', closed_on=? where bug_id=?";
		try {
			PreparedStatement stmt= conn.prepareStatement(sql);
			stmt.setDate(1, new Date(Calendar.getInstance().getTime().getTime()));
			stmt.setInt(2, bugId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void closeConnection() {
		if(conn != null)
		{
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public List<User> getProjectUsers(int proj_id) {
		// TODO Auto-generated method stub
		return null;
	}

}
