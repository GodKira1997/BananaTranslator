package com.hsbc.bts.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.bts.services.ImportService;
import com.hsbc.bts.services.impl.ImportServiceImpl;

/**
 * Servlet implementation class ImportUser
 */
@WebServlet("/ImportUser")
public class ImportUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImportUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("hellosac");
		ImportService imp = new ImportServiceImpl();
		imp.importUsers("F:\\ppp\\Banana_Bug\\WebContent\\userinfo.xml");
		// homePage with registerinfo after import to be done on jsp
		
		request.setAttribute("name", "register");
		RequestDispatcher obb = request.getRequestDispatcher("/homepage.jsp");
		PrintWriter print= response.getWriter();
		print.write("<style>#notify {"
				+ "position: absolute;"
				+ "z-index: 10;"
				+ "color: black;"
				+ "text-align: center;"
				+ "margin-top: 40vh;"
				+ "margin-left: 30vw;"
				+ "padding: 0;"
				+ "width: 40vw;"
				+ "height: 20vh;"
				+ "font-weight: 900;"
				+ "font-size: 6vh;"
				+ "background: rgba(1,1,1,0.4);"
				+ "}"
				+ "#text-notify {"
				+ "margin-top:7vh;"
				+ "text-align:center;"
				+ "}"
				+ "</style>");
		print.write("<div id='notify'><div id='text-notify'>Records updated in DB</div></div>"
				+ " <script>"
				+ "var x= document.getElementById('notify');"
				+ "setTimeout(function(){x.style.display=\"none\";"
				+ "},3000); </script>   ");
		
		obb.include(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
