package com.hsbc.bts.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.bts.services.ImportService;
import com.hsbc.bts.services.impl.ImportServiceImpl;

/**
 * Servlet implementation class ImportUser
 */
@WebServlet("/ImportUser")
public class ImportUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ImportUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("hellosac");
		ImportService imp = new ImportServiceImpl();
		imp.importUsers("F:\\ppp\\Banana_Bug\\WebContent\\userinfo.xml");
		// homePage with registerinfo after import to be done on jsp
		RequestDispatcher obb = request.getRequestDispatcher("/homepage.jsp");
		/*
		 * PrintWriter pw = response.getWriter(); pw.write(
		 * "<script>document.getElementById('register_button').click();</script>");
		 */
		obb.include(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
