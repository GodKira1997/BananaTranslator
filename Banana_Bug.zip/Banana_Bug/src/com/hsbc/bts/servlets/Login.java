package com.hsbc.bts.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.bts.models.User;
import com.hsbc.bts.services.LoginService;
import com.hsbc.bts.services.impl.LoginServiceImpl;

/**
 * Servlet implementation class Login
 */
@WebServlet(name = "LoginServlet", urlPatterns = { "/Login" })
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String email = request.getParameter("email");
			String password = request.getParameter("password");
			
			LoginService ls = new LoginServiceImpl();
			User loginUser = ls.login(email, password);
			String role_name = loginUser.getRole().getRoleName();
			int loginUserId = loginUser.getUserId();
			String lastLogin= loginUser.getLastLogin();
			System.out.println("From servlet"+lastLogin);
			
			System.out.println("loginUserId,role_name"+loginUserId+role_name);
			if(role_name!=null)
			{	
				
				HttpSession session = request.getSession(true);
				session.setAttribute("userId",loginUserId);
				session.setAttribute("userRole", role_name);
				session.setAttribute("lastLogin", lastLogin);
				RequestDispatcher obb = request.getRequestDispatcher("/" + role_name + ".jsp");
				obb.forward(request, response);
			}
			else
			{
				RequestDispatcher obb = request.getRequestDispatcher("/homepage.jsp");
				obb.include(request, response);
			}
			
	}

}
