package com.hsbc.bts.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.bts.dao.UserDAO;
import com.hsbc.bts.dao.impl.UserDAOImpl;
import com.hsbc.bts.services.RegisterService;
import com.hsbc.bts.services.impl.RegisterServiceImpl;


/**
 * Servlet implementation class RegisterUser
 */
@WebServlet("/RegisterUser")
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String email = request.getParameter("email");
		String role = request.getParameter("role");
		String password = request.getParameter("password");
		
		RegisterService rs = new RegisterServiceImpl();
		
		RequestDispatcher obb = request.getRequestDispatcher("/homepage.jsp");
		
		if(!rs.register(email, password, role)) {
			System.out.println("not same");
			
		    obb.include(request, response);
		}
		
		obb.include(request, response);
	}

}
