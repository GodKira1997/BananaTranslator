package com.hsbc.bts.services;

public interface RegisterService {
	boolean register(String email, String password, String role);
}
