package com.hsbc.bts.services;

public interface ImportService {
	void importUsers(String path);
}
