package com.hsbc.bts.services.impl;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;

import com.hsbc.bts.dao.UserDAO;
import com.hsbc.bts.dao.impl.UserDAOImpl;
import com.hsbc.bts.services.RegisterService;

public class RegisterServiceImpl implements RegisterService {

	@Override
	public boolean register(String email, String password, String role) {
		UserDAO userDao = new UserDAOImpl();
		
		
		
		if(userDao.setPassword(email, role, password)) {
			return true;
		}
		return false;
	}

}
