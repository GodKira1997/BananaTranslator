package com.hsbc.bts.services.impl;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.hsbc.bts.dao.UserDAO;
import com.hsbc.bts.dao.impl.UserDAOImpl;
import com.hsbc.bts.services.ImportService;


public class ImportServiceImpl implements ImportService {

	@Override
	public void importUsers(String path) {
		
		UserDAO ud = new UserDAOImpl();
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db;
        try {
            db = dbf.newDocumentBuilder();
            Document doc = db.parse(path);
            NodeList n1 = doc.getElementsByTagName("name");
            NodeList n2 = doc.getElementsByTagName("type");
            NodeList n3 = doc.getElementsByTagName("email");
            String name, email, roleName;
            
            for (int i = 0; i < n1.getLength(); i++) {
                
            	name = n1.item(i).getFirstChild().getNodeValue();
            	roleName = n2.item(i).getFirstChild().getNodeValue();
            	email = n3.item(i).getFirstChild().getNodeValue();
            	
            	System.out.println(n1.item(i).getFirstChild().getNodeValue());
                System.out.println(n2.item(i).getFirstChild().getNodeValue());
                System.out.println(n3.item(i).getFirstChild().getNodeValue());
                if(!ud.checkUser(email))
                {
                	ud.addUser(email, name, roleName);
                }
            }

        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (IOException e) {
        	e.printStackTrace();
        }

	}

}
