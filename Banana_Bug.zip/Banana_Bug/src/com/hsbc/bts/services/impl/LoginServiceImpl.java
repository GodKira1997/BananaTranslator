package com.hsbc.bts.services.impl;

import com.hsbc.bts.dao.UserDAO;
import com.hsbc.bts.dao.impl.UserDAOImpl;
import com.hsbc.bts.models.User;
import com.hsbc.bts.services.LoginService;

public class LoginServiceImpl implements LoginService {

	@Override
	public User login(String email, String password) {
		
		UserDAO ud  = new UserDAOImpl();
		
		return ud.loginUser(email, password);
		
	}

	@Override
	public User getUserDetails(String email) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserDetails(int userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
