package com.hsbc.bts.services;

import com.hsbc.bts.models.User;

public interface LoginService {
	User login(String email,String password); //returns user object
	User getUserDetails(String email);
	User getUserDetails(int userId);
}
