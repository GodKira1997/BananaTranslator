package com.hsbc.bts.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

import com.hsbc.bts.services.LoginService;
import com.hsbc.bts.services.ProjectService;
import com.hsbc.bts.services.RegisterService;

public class BTSFactory {
	public static Object getInstance(String serviceImpl) {
		Object proxy = null;

		try {
			Object obj = (Object) Class.forName(serviceImpl).newInstance();
			
			InvocationHandler logger = new Interceptor(obj);
			
			proxy = (Object) Proxy.newProxyInstance(obj.getClass().getClassLoader(), new Class[] {LoginService.class,ProjectService.class,RegisterService.class}, logger);
			
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return proxy;
	}
}
