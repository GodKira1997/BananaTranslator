package com.hsbc.bts.proxy;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.Date;

import com.hsbc.bts.annotations.Log;
import com.hsbc.bts.annotations.Login;
import com.hsbc.bts.models.User;

public class Interceptor implements InvocationHandler {

	Object obj;
	
	public Interceptor(Object obj) {
		this.obj = obj;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		Object result = null;
		
		//Custom Annotation "Log" which specifies
		//if ENTRY and EXIT log is created or not
		Log log = method.getDeclaredAnnotation(Log.class);
		
		//Custom Annotation "Log" which specifies
		//Login log file is created or not
		Login login = method.getDeclaredAnnotation(Login.class);
		BufferedWriter bw =new BufferedWriter(new FileWriter("E:\\sts-workspace\\Banana_Bug\\WebContent\\log.txt"));
		
		if(log != null)
			System.out.println("\nENTRY | Method name: " + method.getName());
		try {
			result = method.invoke(obj, args);
			if(login != null) {
				String loginLog = ((User) result).getEmail() + " " + new Timestamp(new Date().getTime())+"\n";
				System.out.println(loginLog);
				bw.append(loginLog);
				bw.close();
			}
			
			if(log != null)
				System.out.println("EXIT | Method name: " + method.getName() + "\n");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
