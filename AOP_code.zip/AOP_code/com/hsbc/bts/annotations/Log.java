package com.hsbc.bts.annotations;

import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

//Annotation for creating ENTRY and EXIT logs
@Retention(RUNTIME)
@Target(METHOD)
public @interface Log {

}
