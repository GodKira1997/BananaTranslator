package com.hsbc.bts.test;

import com.hsbc.bts.proxy.BTSFactory;
import com.hsbc.bts.services.LoginService;

public class TestBTSFactory {

	public static void main(String[] args) {
		
		LoginService loginService = null;
		
		loginService = (LoginService) BTSFactory.getInstance("com.hsbc.bts.services.impl.LoginServiceImpl");
		
		loginService.login("HI", "BYE");

	}

}
